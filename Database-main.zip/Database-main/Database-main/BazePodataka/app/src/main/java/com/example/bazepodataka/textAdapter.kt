package com.example.bazepodataka

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.bazepodataka.databinding.TextItemBinding
import com.google.firebase.database.ValueEventListener


//2 varijable koje prima lista
//listener vraća int vrijednost
class textAdapter(
    private val list: ArrayList<text>,
    private val th: Context,

    //RecyclerView nam je interface
    //On zahtijeva implementaciju određenih metoda od klase
    private val listener: (text) -> Unit):RecyclerView.Adapter<textAdapter.ViewHolder>(){


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): textAdapter.ViewHolder {

        //pošto ne možemo napraviti layoutinflater na cijeli layout, moramo ga napraviti za svaki element posebno
        //th je kontekst odnosno this@MainActivity
        //inflate-at će svaki item iz MainActivity

        val v = TextItemBinding.inflate(LayoutInflater.from(th), parent, false)
        return ViewHolder(v)

    }

    override fun onBindViewHolder(holder: textAdapter.ViewHolder, position: Int) {

        //onBindViewHolder se pokreće onoliko puta koliko ima elemenata
        //prosljeđuje elemente u bindItem

        holder.bindItem(list[position], th)

        //na svaku poziciju stavlja listener

        holder.itemView.setOnClickListener{
            listener(list[position])
        }



    }

    override fun getItemCount(): Int {

        //vraća broj elemenata u listi
        return list.size
    }


    class ViewHolder (private var textBinding: TextItemBinding):RecyclerView.ViewHolder(textBinding.root){

        fun bindItem(text:text, th:Context){
            textBinding.number.text = text.id.toString()
            textBinding.desc.text = text.desc
            textBinding.text.text = text.text
        }
    }
}