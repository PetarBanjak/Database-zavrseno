package com.example.bazepodataka

//nova klasa
data class text(

    var text:String = "", var id: Int = 0,
    var desc:String = ""

)

