package com.example.bazepodataka

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.bazepodataka.databinding.ActivityMainBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    private var database : DatabaseReference = FirebaseDatabase.getInstance("https://bazapodataka-a36d6-default-rtdb.europe-west1.firebasedatabase.app/").getReference("text")
    //referneca za našu BP

    var list = ArrayList<text>()
    //lista stvari koje se nalaze i ListView

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.commit.setOnClickListener{

            val text = binding.unos.text.toString()
            val opis = binding.desc.text.toString()

            var id = 0
            if(list.size>0)
              id=list[list.size - 1].id + 1

            list.add(text(text, id, opis))

            database.setValue(list)



        }

        database.addValueEventListener(object: ValueEventListener{

            var list2 = ArrayList<text>()


            override fun onDataChange(snapshot: DataSnapshot) {
                try {
                    list.clear()
                    list2.clear()
                    //lista naše klase
                    //snapshot - prikaz ternutnih podataka baze
                    //.children - sve što je pod linkom dataReference je children
                    //.map - određuje na koji način oređujemo kako ćemo posložiti stvari iz lise
                    //!! - non null assertion - forsira da ne bude null
                    val a: List<text> = snapshot.children.map { dataSnapshot -> dataSnapshot.getValue(text::class.java)!!}


                    //u listu smo dodali value a koju smo pozvali
                    list2.addAll(a)


                }
                catch (_:Exception){}

                //npr. ako nemam interneta da nam se ne crasha apk nego jednostavno da kaže no int connection




                for(v in list2)
                    list.add(v)


                //govori nam kako ćemo poslagati elemente u listu odnsono recycler
                //LinearLayout postavlja jedno ispod drugog
                //stavili smo da postavlja vertikalno
                //false - gore 1. element dole, zadnji element

                binding.recycler.apply { layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)


                    //adapter - stvar na koji način dodavamo elemente u recyclerView
                    //position -> - govori što nam adapter vraća
                    adapter = textAdapter(list, this@MainActivity){
                        position -> Toast.makeText(this@MainActivity, "Kliknuli ste na ${position.text}. element", Toast.LENGTH_SHORT).show()

                        list.remove(position)
                        database.setValue(list)
                    }

                }


            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@MainActivity,"error: ${error}",Toast.LENGTH_SHORT).show()
            }

        })



            }
        }






